<template>
  <div class="plist" dir="rtl">

    <!-- ── سەرپەڕە ── -->
    <div class="plist__head">
      <div>
        <h1 class="plist__title">پڕۆژەکان</h1>
        <p class="plist__sub">بینین، گەڕان و بەڕێوەبردنی هەموو پڕۆژەکان</p>
      </div>
      <RouterLink class="btn btn--primary" to="/admin/projects/new">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        پڕۆژەی نوێ
      </RouterLink>
    </div>

    <!-- ── شریتی گەڕان ── -->
    <div class="plist__bar">
      <div class="search">
        <svg class="search__ico" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
        <input v-model="searchQ" class="search__input" placeholder="گەڕان بە ناونیشان، تاگ یان کیووەرد…" @input="onSearch" />
        <Transition name="fade">
          <button v-if="searchQ" class="search__clear" @click="clearSearch">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </Transition>
      </div>
      <select v-model="filterLang" class="sel" @change="load">
        <option value="">هەموو زمانەکان</option>
        <option value="CKB">سۆرانی</option>
        <option value="KMR">کورمانجی</option>
      </select>
      <!-- ✅ فیلتەری دۆخ -->
      <select v-model="filterStatus" class="sel" @change="load">
        <option value="">هەموو دۆخەکان</option>
        <option value="ONGOING">بەردەوام</option>
        <option value="COMPLETED">تەواو</option>
      </select>
    </div>

    <!-- ── ئاگاداری ── -->
    <Transition name="slide-down">
      <div v-if="toast.show" class="toast" :class="`toast--${toast.type}`">
        <span class="toast__ico">{{ toast.type === 'success' ? '✓' : '✕' }}</span>
        {{ toast.msg }}
      </div>
    </Transition>

    <!-- ── بارکردن ── -->
    <div v-if="loading" class="skeletons">
      <div class="skel" v-for="i in 6" :key="i" :style="{ animationDelay: `${i * 0.07}s` }"></div>
    </div>

    <!-- ── هەڵە ── -->
    <div v-else-if="error" class="state-box state-box--error">
      <div class="state-box__ico"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></div>
      <p>{{ error }}</p>
      <button class="btn btn--ghost btn--sm" @click="load">دووبارەتەکەیەوە</button>
    </div>

    <!-- ── بەتاڵ ── -->
    <div v-else-if="!projects.length" class="state-box">
      <div class="state-box__ico"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg></div>
      <p>هیچ پڕۆژەیەک نەدۆزرایەوە</p>
      <RouterLink class="btn btn--primary btn--sm" to="/admin/projects/new">یەکەمین پڕۆژەت زیاد بکە</RouterLink>
    </div>

    <!-- ── خشتە ── -->
    <div v-else class="table-wrap">
      <div class="table-meta">کۆی {{ totalItems }} پڕۆژە<span v-if="searchQ"> — ئەنجامی گەڕان بۆ «{{ searchQ }}»</span></div>
      <table class="tbl">
        <thead>
          <tr>
            <th style="width:52px">#</th>
            <th style="width:66px">ڕووکار</th>
            <th>ناونیشانی سۆرانی</th>
            <th>ناونیشانی کورمانجی</th>
            <th style="width:160px">جۆر</th>
            <th style="width:100px">دۆخ</th>
            <th style="width:112px">بەروار</th>
            <th style="width:88px">زمان</th>
            <th style="width:72px">میدیا</th>
            <th style="width:116px">کردار</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="p in filteredProjects" :key="p.id" class="tbl__row" @click="openDetail(p)">
            <td><span class="tbl__id">#{{ p.id }}</span></td>
            <td>
              <div class="cover-wrap" v-if="p.coverUrl"><img class="cover-img" :src="p.coverUrl" loading="lazy" /></div>
              <div class="cover-empty" v-else><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg></div>
            </td>
            <td>
              <div class="tbl__name">{{ p.ckbContent?.title || '—' }}</div>
              <div v-if="p.ckbContent?.location" class="tbl__loc"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>{{ p.ckbContent.location }}</div>
            </td>
            <td>
              <div class="tbl__name tbl__name--kmr">{{ p.kmrContent?.title || '—' }}</div>
              <div v-if="p.kmrContent?.location" class="tbl__loc"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>{{ p.kmrContent.location }}</div>
            </td>
            <!-- ✅ جۆری دوو زمانە: نیشاندانی ئەوی پەیوەندیدارە بە پشتبەستن بە زمانە بەردەستەکان -->
            <td>
              <div v-if="p.projectTypeCkb" class="tbl__type-row">
                <span class="pill pill--type pill--ckb">{{ p.projectTypeCkb }}</span>
              </div>
              <div v-if="p.projectTypeKmr" class="tbl__type-row" style="margin-top:.25rem;">
                <span class="pill pill--type pill--kmr">{{ p.projectTypeKmr }}</span>
              </div>
              <span v-if="!p.projectTypeCkb && !p.projectTypeKmr" class="tbl__dash">—</span>
            </td>
            <!-- ✅ نیشانەی دۆخ -->
            <td>
              <span class="status-pill" :class="p.status === 'COMPLETED' ? 'status-pill--completed' : 'status-pill--ongoing'">
                <span class="status-pill__dot"></span>
                {{ p.status === 'COMPLETED' ? 'تەواو' : 'بەردەوام' }}
              </span>
            </td>
            <td class="tbl__date">{{ fmtDate(p.projectDate) }}</td>
            <td><div class="lang-row"><span v-for="l in (p.contentLanguages||[])" :key="l" class="lang-dot" :class="`lang-dot--${l.toLowerCase()}`">{{ l }}</span></div></td>
            <td><span class="media-pill" v-if="p.media?.length"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>{{ p.media.length }}</span><span v-else class="tbl__dash">—</span></td>
            <td @click.stop>
              <div class="tbl__acts">
                <button class="act act--view" title="تەواوی زانیاری" @click="openDetail(p)"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></button>
                <RouterLink class="act act--edit" :to="`/admin/projects/${p.id}/edit`"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4z"/></svg></RouterLink>
                <button class="act act--del" @click="confirmDelete(p)"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg></button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- ── پەڕەگەڕان ── -->
    <div v-if="totalPages > 1" class="pager">
      <button class="pager__btn" :disabled="page===0" @click="changePage(page-1)"><svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M10 3l-5 5 5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>
      <button v-for="p in pageRange" :key="p" class="pager__btn" :class="{'pager__btn--on':p===page}" @click="changePage(p)">{{ p+1 }}</button>
      <button class="pager__btn" :disabled="page>=totalPages-1" @click="changePage(page+1)"><svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M6 3l5 5-5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>
    </div>

    <!-- ══ داخستنەوەی سڕینەوە ══ -->
    <Teleport to="body">
      <Transition name="modal">
        <div v-if="delTarget" class="overlay" @click.self="delTarget=null">
          <div class="del-modal">
            <div class="del-modal__ico"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#8C1515" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg></div>
            <h3 class="del-modal__title">دڵنیای لە سڕینەوە؟</h3>
            <p class="del-modal__body">پڕۆژەی <strong>«{{ ckbTitle(delTarget) || '#'+delTarget.id }}»</strong><br/>بە تەواوی سڕاوەتەوە و ناگەڕێتەوە.</p>
            <div class="del-modal__acts">
              <button class="btn btn--ghost" @click="delTarget=null">نەخێر</button>
              <button class="btn btn--danger" :disabled="deleting" @click="doDelete"><span v-if="deleting" class="spinner"></span>{{ deleting?'…':'بەڵێ، بیسڕەوە' }}</button>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>

    <!-- ══ داخستنەوەی وردەکاری پڕۆژە ══ -->
    <Teleport to="body">
      <Transition name="pdm-fade">
        <div v-if="detail" class="pdm-overlay" @click.self="closeDetail" @keydown.esc="closeDetail">
          <Transition name="pdm-rise" appear>
            <div v-if="detail" class="pdm" role="dialog" :aria-label="activeContent(detail)?.title">

              <!-- داخستن -->
              <button class="pdm-x" @click="closeDetail" aria-label="داخستن">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>

              <!-- ════ چەپ — میدیا ════ -->
              <div class="pdm-media">
                <div class="pdm-media__empty" v-if="!allMediaItems.length">
                  <div class="pdm-media__empty-icon">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                  </div>
                  <span>هیچ میدیایەک نییە</span>
                  <img v-if="detail.coverUrl" :src="detail.coverUrl" class="pdm-media__cover-fallback" />
                </div>

                <div class="pdm-stage" v-else>
                  <!-- وێنە -->
                  <div v-if="currentMedia.type === 'IMAGE'" class="pdm-stage__image-wrap">
                    <img
                      v-if="currentMedia.imageUrl"
                      :src="currentMedia.imageUrl"
                      :key="currentMedia.imageUrl"
                      class="pdm-stage__image"
                      :alt="currentMedia.caption || ''"
                    />

                    <iframe
                      v-else-if="currentMedia.iframeUrl"
                      :src="currentMedia.iframeUrl"
                      :key="currentMedia.iframeUrl"
                      title="وێنە/میدیای جێگیرکراو"
                      style="width:100%; height:100%; min-height:360px; border:0; background:#000;"
                      allow="autoplay; encrypted-media; picture-in-picture"
                      allowfullscreen
                    ></iframe>

                    <div v-else class="pdm-doc-card">
                      <div class="pdm-doc-card__icon">
                        <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4">
                          <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
                          <polyline points="14 2 14 8 20 8"/>
                        </svg>
                      </div>
                      <div class="pdm-doc-card__type">وێنە</div>
                      <div class="pdm-doc-card__name">{{ currentMedia.caption || 'وێنە' }}</div>
                      <div class="pdm-doc-card__actions" v-if="currentMedia.openUrl">
                        <a :href="currentMedia.openUrl" target="_blank" class="pdm-doc-btn pdm-doc-btn--primary">کردنەوەی لینک</a>
                      </div>
                    </div>

                    <div class="pdm-stage__caption" v-if="currentMedia.caption">{{ currentMedia.caption }}</div>
                  </div>

                  <!-- ڤیدیۆ -->
                  <div v-else-if="currentMedia.type === 'VIDEO'" class="pdm-stage__video-wrap">
                    <!-- بە کارهێنانی embed بۆ یوتیوب / ڤیمێۆ / گووگڵ درایڤ -->
                    <iframe
                      v-if="currentMedia.iframeUrl"
                      :src="currentMedia.iframeUrl"
                      :key="currentMedia.iframeUrl"
                      class="pdm-stage__video"
                      title="ڤیدیۆی جێگیرکراو"
                      style="border:0;"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                      allowfullscreen
                      referrerpolicy="strict-origin-when-cross-origin"
                    ></iframe>

                    <!-- فایلی ڤیدیۆی ڕاستەوخۆ (.mp4/.webm/...) -->
                    <video
                      v-else-if="currentMedia.videoUrl"
                      :key="currentMedia.videoUrl"
                      class="pdm-stage__video"
                      controls
                      controlsList="nodownload"
                      preload="metadata"
                      playsinline
                    >
                      <source :src="currentMedia.videoUrl" :type="currentMedia.mimeType || undefined" />
                      وێبگەڕەکەت پشتگیری لەم ڤیدیۆیە ناکات.
                    </video>

                    <!-- جێگرەوە کاتێک تەنها لینکی دەرەکی هەیە -->
                    <div v-else class="pdm-stage__doc-wrap">
                      <div class="pdm-doc-card">
                        <div class="pdm-doc-card__icon">
                          <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4">
                            <polygon points="23 7 16 12 23 17 23 7"/>
                            <rect x="1" y="5" width="15" height="14" rx="2"/>
                          </svg>
                        </div>
                        <div class="pdm-doc-card__type">ڤیدیۆ</div>
                        <div class="pdm-doc-card__name">{{ currentMedia.caption || 'ڤیدیۆ' }}</div>
                        <div class="pdm-doc-card__actions" v-if="currentMedia.openUrl">
                          <a :href="currentMedia.openUrl" target="_blank" class="pdm-doc-btn pdm-doc-btn--primary">
                            کردنەوەی ڤیدیۆ
                          </a>
                        </div>
                      </div>
                    </div>

                    <div class="pdm-stage__caption" v-if="currentMedia.caption">{{ currentMedia.caption }}</div>
                  </div>

                  <!-- دەنگ -->
                  <div v-else-if="currentMedia.type === 'AUDIO'" class="pdm-stage__audio-wrap">
                    <div class="pdm-audio-player">
                      <div class="pdm-audio-player__wave">
                        <span v-for="i in 32" :key="i" class="pdm-audio-player__bar" :style="{ animationDelay: `${i * 0.06}s`, height: `${18 + Math.sin(i * 0.8) * 14}px` }"></span>
                      </div>
                      <div class="pdm-audio-player__title">{{ currentMedia.caption || 'دەنگ' }}</div>

                      <!-- دەنگی جێگیرکراو (وەک ساوندکلاوود) -->
                      <iframe
                        v-if="currentMedia.iframeUrl"
                        :src="currentMedia.iframeUrl"
                        :key="currentMedia.iframeUrl"
                        title="دەنگی جێگیرکراو"
                        style="width:100%; min-height:130px; border:0; border-radius:8px; background:#111;"
                        allow="autoplay"
                      ></iframe>

                      <!-- فایلی دەنگی ڕاستەوخۆ -->
                      <audio
                        v-else-if="currentMedia.audioUrl"
                        :key="currentMedia.audioUrl"
                        class="pdm-audio-player__ctrl"
                        controls
                        controlsList="nodownload"
                        preload="metadata"
                      >
                        <source :src="currentMedia.audioUrl" :type="currentMedia.mimeType || undefined" />
                        وێبگەڕەکەت پشتگیری لەم دەنگە ناکات.
                      </audio>

                      <!-- جێگرەوە -->
                      <div v-else style="color: rgba(255,255,255,.65); font-size:.85rem; text-align:center;">
                        پێشبینینی دەنگ بەردەست نییە، بەڵام دەتوانیت لینکەکە بکەیتەوە.
                      </div>

                      <a v-if="currentMedia.openUrl" :href="currentMedia.openUrl" target="_blank" class="pdm-ext-link">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                        لینک / پلەیەر دەرەکی
                      </a>
                    </div>
                  </div>

                  <!-- بەلگەنامە/PDF -->
                  <div v-else-if="currentMedia.type === 'PDF' || currentMedia.type === 'DOCUMENT'" class="pdm-stage__doc-wrap">
                    <!-- پیشاندانی ناوهێڵ کاتێک بەردەستە -->
                    <iframe
                      v-if="currentMedia.docPreviewUrl"
                      :src="currentMedia.docPreviewUrl"
                      :key="currentMedia.docPreviewUrl"
                      title="پێشبینینی بەلگەنامە"
                      style="width:100%; height:100%; min-height:360px; border:0; background:#fff;"
                    ></iframe>

                    <!-- کارتی جێگرەوە -->
                    <div v-else class="pdm-doc-card">
                      <div class="pdm-doc-card__icon">
                        <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                      </div>
                      <div class="pdm-doc-card__type">{{ currentMedia.type === 'PDF' ? 'PDF' : 'بەلگەنامە' }}</div>
                      <div class="pdm-doc-card__name">{{ currentMedia.caption || 'بەلگەنامە' }}</div>
                      <div class="pdm-doc-card__actions">
                        <a v-if="currentMedia.openUrl" :href="currentMedia.openUrl" target="_blank" class="pdm-doc-btn pdm-doc-btn--primary">
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                          کردنەوەی فایل
                        </a>
                      </div>
                    </div>
                  </div>

                  <div v-else-if="detail.coverUrl" class="pdm-stage__image-wrap">
                    <img :src="detail.coverUrl" class="pdm-stage__image" alt="ڕووکار" />
                  </div>

                  <button v-if="allMediaItems.length > 1" class="pdm-arrow pdm-arrow--prev" @click="prevMedia" :disabled="mediaIdx === 0">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M15 18l-6-6 6-6"/></svg>
                  </button>
                  <button v-if="allMediaItems.length > 1" class="pdm-arrow pdm-arrow--next" @click="nextMedia" :disabled="mediaIdx === allMediaItems.length - 1">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M9 18l6-6-6-6"/></svg>
                  </button>
                  <div class="pdm-counter" v-if="allMediaItems.length > 1">{{ mediaIdx + 1 }} / {{ allMediaItems.length }}</div>
                </div>

                <div class="pdm-thumbs" v-if="allMediaItems.length > 1">
                  <button v-for="(m, i) in allMediaItems" :key="i" class="pdm-thumb" :class="{ 'pdm-thumb--on': i === mediaIdx }" @click="mediaIdx = i">
                    <img v-if="m.type === 'IMAGE' && (m.imageUrl || m.url)" :src="m.imageUrl || m.url" loading="lazy" />
                    <span v-else-if="m.type === 'VIDEO'" class="pdm-thumb__icon pdm-thumb__icon--video"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg></span>
                    <span v-else-if="m.type === 'AUDIO'" class="pdm-thumb__icon pdm-thumb__icon--audio"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></span>
                    <span v-else class="pdm-thumb__icon pdm-thumb__icon--doc"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></span>
                    <span class="pdm-thumb__bar" v-if="i === mediaIdx"></span>
                  </button>
                </div>
              </div>

              <!-- ════ ڕاست — پانێڵی وردەکاری ════ -->
              <div class="pdm-info">
                <div class="pdm-info__head">
                  <div class="pdm-info__head-meta">
                    <span class="pdm-id-tag"># {{ detail.id }}</span>
                    <!-- ✅ نیشانەی دۆخ لە داخستنەوەی وردەکاری -->
                    <span class="pdm-status-badge" :class="detail.status === 'COMPLETED' ? 'pdm-status-badge--completed' : 'pdm-status-badge--ongoing'">
                      <span class="pdm-status-badge__dot"></span>
                      {{ detail.status === 'COMPLETED' ? 'تەواو' : 'بەردەوام' }}
                    </span>
                  </div>

                  <!-- ✅ نیشاندانی جۆری دوو زمانە لە وردەکاری -->
                  <div class="pdm-types" v-if="detail.projectTypeCkb || detail.projectTypeKmr">
                    <span v-if="detail.projectTypeCkb" class="pdm-type-tag pdm-type-tag--ckb">{{ detail.projectTypeCkb }}</span>
                    <span v-if="detail.projectTypeKmr" class="pdm-type-tag pdm-type-tag--kmr">{{ detail.projectTypeKmr }}</span>
                  </div>

                  <h2 class="pdm-title">{{ activeContent(detail)?.title || '—' }}</h2>
                  <p class="pdm-subtitle" v-if="detail.kmrContent?.title && detail.ckbContent?.title !== detail.kmrContent?.title">
                    {{ detail.contentLanguages?.includes('CKB') ? detail.kmrContent.title : detail.ckbContent?.title }}
                  </p>

                  <div class="pdm-langs">
                    <span v-for="l in detail.contentLanguages" :key="l" class="pdm-lang" :class="`pdm-lang--${l.toLowerCase()}`">
                      {{ l === 'CKB' ? 'سۆرانی' : 'کورمانجی' }}
                    </span>
                    <span class="pdm-date" v-if="detail.projectDate">
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                      {{ fmtDate(detail.projectDate) }}
                    </span>
                  </div>

                  <RouterLink class="pdm-edit-btn" :to="`/admin/projects/${detail.id}/edit`" @click="closeDetail">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4z"/></svg>
                    دەستکاری پڕۆژە
                  </RouterLink>
                </div>

                <div class="pdm-tabs" v-if="detail.contentLanguages?.length > 1">
                  <button v-for="l in detail.contentLanguages" :key="l" class="pdm-tab" :class="{ 'pdm-tab--on': detailLang === l }" @click="detailLang = l">
                    <span class="pdm-tab__pip" :class="`pdm-tab__pip--${l.toLowerCase()}`"></span>
                    {{ l === 'CKB' ? 'سۆرانی' : 'کورمانجی' }}
                  </button>
                </div>

                <div class="pdm-info__body">

                  <!-- وەسف -->
                  <div class="acc" v-if="activeContent(detail)?.description">
                    <button class="acc__hd" @click="toggleAcc('desc')">
                      <span class="acc__hd-left"><span class="acc__ico acc__ico--desc"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="14 2 14 8 20 8"/></svg></span><span class="acc__title">وەسف</span></span>
                      <svg class="acc__chevron" :class="{ 'acc__chevron--open': openAccordions.has('desc') }" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 9l6 6 6-6"/></svg>
                    </button>
                    <Transition name="acc-body">
                      <div v-if="openAccordions.has('desc')" class="acc__body">
                        <p class="acc__text acc__text--desc">{{ activeContent(detail).description }}</p>
                      </div>
                    </Transition>
                  </div>

                  <!-- شوێن -->
                  <div class="acc" v-if="activeContent(detail)?.location">
                    <button class="acc__hd" @click="toggleAcc('loc')">
                      <span class="acc__hd-left"><span class="acc__ico acc__ico--loc"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg></span><span class="acc__title">شوێن</span></span>
                      <svg class="acc__chevron" :class="{ 'acc__chevron--open': openAccordions.has('loc') }" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 9l6 6 6-6"/></svg>
                    </button>
                    <Transition name="acc-body">
                      <div v-if="openAccordions.has('loc')" class="acc__body">
                        <div class="acc__location"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>{{ activeContent(detail).location }}</div>
                      </div>
                    </Transition>
                  </div>

                  <!-- ناوەڕۆکەکان -->
                  <div class="acc" v-if="activeContents(detail).length">
                    <button class="acc__hd" @click="toggleAcc('contents')">
                      <span class="acc__hd-left"><span class="acc__ico acc__ico--content"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></span><span class="acc__title">ناوەڕۆکەکان</span><span class="acc__badge">{{ activeContents(detail).length }}</span></span>
                      <svg class="acc__chevron" :class="{ 'acc__chevron--open': openAccordions.has('contents') }" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 9l6 6 6-6"/></svg>
                    </button>
                    <Transition name="acc-body">
                      <div v-if="openAccordions.has('contents')" class="acc__body">
                        <div class="acc__chips"><span v-for="t in activeContents(detail)" :key="t" class="acc__chip acc__chip--content">{{ t }}</span></div>
                      </div>
                    </Transition>
                  </div>

                  <!-- تاگەکان -->
                  <div class="acc" v-if="activeTags(detail).length">
                    <button class="acc__hd" @click="toggleAcc('tags')">
                      <span class="acc__hd-left"><span class="acc__ico acc__ico--tag"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg></span><span class="acc__title">تاگەکان</span><span class="acc__badge acc__badge--tag">{{ activeTags(detail).length }}</span></span>
                      <svg class="acc__chevron" :class="{ 'acc__chevron--open': openAccordions.has('tags') }" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 9l6 6 6-6"/></svg>
                    </button>
                    <Transition name="acc-body">
                      <div v-if="openAccordions.has('tags')" class="acc__body">
                        <div class="acc__chips"><span v-for="t in activeTags(detail)" :key="t" class="acc__chip acc__chip--tag"><svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/></svg>{{ t }}</span></div>
                      </div>
                    </Transition>
                  </div>

                  <!-- کیووەردەکان -->
                  <div class="acc" v-if="activeKeywords(detail).length">
                    <button class="acc__hd" @click="toggleAcc('kw')">
                      <span class="acc__hd-left"><span class="acc__ico acc__ico--kw"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg></span><span class="acc__title">کیووەردەکان</span><span class="acc__badge acc__badge--kw">{{ activeKeywords(detail).length }}</span></span>
                      <svg class="acc__chevron" :class="{ 'acc__chevron--open': openAccordions.has('kw') }" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 9l6 6 6-6"/></svg>
                    </button>
                    <Transition name="acc-body">
                      <div v-if="openAccordions.has('kw')" class="acc__body">
                        <div class="acc__chips"><span v-for="t in activeKeywords(detail)" :key="t" class="acc__chip acc__chip--kw">{{ t }}</span></div>
                      </div>
                    </Transition>
                  </div>

                  <!-- لیستی میدیا -->
                  <div class="acc" v-if="allMediaItems.length">
                    <button class="acc__hd" @click="toggleAcc('media')">
                      <span class="acc__hd-left"><span class="acc__ico acc__ico--media"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg></span><span class="acc__title">میدیاکان</span><span class="acc__badge acc__badge--media">{{ allMediaItems.length }}</span></span>
                      <svg class="acc__chevron" :class="{ 'acc__chevron--open': openAccordions.has('media') }" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 9l6 6 6-6"/></svg>
                    </button>
                    <Transition name="acc-body">
                      <div v-if="openAccordions.has('media')" class="acc__body acc__body--flush">
                        <div v-for="(m, i) in allMediaItems" :key="i" class="acc__media-row" :class="{ 'acc__media-row--on': i === mediaIdx }" @click="mediaIdx = i">
                          <div class="acc__media-ico" :class="`acc__media-ico--${m.type?.toLowerCase()}`"><span v-html="mediaIcon(m.type)"></span></div>
                          <div class="acc__media-info">
                            <div class="acc__media-type">{{ m.type === 'IMAGE' ? 'وێنە' : m.type === 'VIDEO' ? 'ڤیدیۆ' : m.type === 'AUDIO' ? 'دەنگ' : m.type === 'PDF' ? 'PDF' : 'بەلگەنامە' }}</div>
                            <div class="acc__media-cap" v-if="m.caption">{{ m.caption }}</div>
                            <div class="acc__media-cap acc__media-cap--url" v-else-if="m.openUrl">{{ m.openUrl }}</div>
                          </div>
                          <div class="acc__media-playing" v-if="i === mediaIdx"><span class="acc__media-playing__dot"></span><span class="acc__media-playing__dot"></span><span class="acc__media-playing__dot"></span></div>
                        </div>
                      </div>
                    </Transition>
                  </div>

                  <!-- زانیاری سیستەم -->
                  <div class="acc acc--system">
                    <button class="acc__hd acc__hd--system" @click="toggleAcc('sys')">
                      <span class="acc__hd-left"><span class="acc__ico acc__ico--sys"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg></span><span class="acc__title">زانیاری سیستەم</span></span>
                      <svg class="acc__chevron" :class="{ 'acc__chevron--open': openAccordions.has('sys') }" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 9l6 6 6-6"/></svg>
                    </button>
                    <Transition name="acc-body">
                      <div v-if="openAccordions.has('sys')" class="acc__body acc__body--flush">
                        <div class="acc__sys-grid">
                          <div class="acc__sys-cell" v-if="detail.createdAt"><div class="acc__sys-k">دروستکراوە لە</div><div class="acc__sys-v">{{ fmtDatetime(detail.createdAt) }}</div></div>
                          <div class="acc__sys-cell" v-if="detail.updatedAt"><div class="acc__sys-k">دواین نوێکردنەوە</div><div class="acc__sys-v">{{ fmtDatetime(detail.updatedAt) }}</div></div>
                          <div class="acc__sys-cell acc__sys-cell--full"><div class="acc__sys-k">شناسەی یەکتا (ID)</div><div class="acc__sys-v acc__sys-v--mono">{{ detail.id }}</div></div>
                          <div class="acc__sys-cell acc__sys-cell--full" v-if="detail.coverUrl"><div class="acc__sys-k">لینکی ڕووکار</div><a :href="detail.coverUrl" target="_blank" class="acc__sys-v acc__sys-v--link">{{ detail.coverUrl }}</a></div>
                        </div>
                      </div>
                    </Transition>
                  </div>

                </div>
              </div>

            </div>
          </Transition>
        </div>
      </Transition>
    </Teleport>

  </div>
</template>
<script setup>
import { ref, reactive, computed, onMounted, defineComponent, h } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import api from '@/api.js'

// ── Inline TagInput component ──────────────────────────────────────────────────
const TagInput = defineComponent({
  name: 'TagInput',
  props: {
    modelValue: { type: Array, default: () => [] },
    placeholder: { type: String, default: 'زیاد بکە…' },
    color: { type: String, default: 'default' },
  },
  emits: ['update:modelValue'],
  setup(props, { emit }) {
    const inp = ref('')
    const add = () => {
      const v = inp.value.trim()
      if (v && !props.modelValue.includes(v)) emit('update:modelValue', [...props.modelValue, v])
      inp.value = ''
    }
    const rem = (i) => {
      const arr = [...props.modelValue]; arr.splice(i, 1); emit('update:modelValue', arr)
    }
    return () => h('div', { class: 'tag-input' }, [
      h('div', { class: 'tag-input__tags' }, [
        ...props.modelValue.map((t, i) =>
          h('span', { class: `tag-input__tag tag-input__tag--${props.color}`, key: t },
            [t, h('button', { type: 'button', onClick: () => rem(i) }, '✕')]
          )
        ),
        h('input', {
          class: 'tag-input__inp', placeholder: props.placeholder, value: inp.value,
          onInput: (e) => { inp.value = e.target.value },
          onKeydown: (e) => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); add() } },
          onBlur: add,
        })
      ])
    ])
  }
})

// ── Setup ─────────────────────────────────────────────────────────────────────
const route  = useRoute()
const router = useRouter()

const isEdit     = computed(() => !!route.params.id)
const activeLang = ref('CKB')
const fetching   = ref(false)
const saving     = ref(false)
const dragOver   = ref(false)
const coverFile  = ref(null)
const coverPreview  = ref('')
const newMediaFiles = ref([])
const toast  = ref({ show: false, type: 'success', msg: '' })
const errors = ref({})

const form = reactive({
  contentLanguages: ['CKB'],
  coverUrl: '',
  projectTypeCkb: '',
  projectTypeKmr: '',
  status: 'ONGOING',
  projectDate: '',
  ckbContent: { title: '', description: '', location: '' },
  kmrContent: { title: '', description: '', location: '' },
  contentsCkb: [], contentsKmr: [],
  tagsCkb: [], tagsKmr: [],
  keywordsCkb: [], keywordsKmr: [],
  media: [],
})

// ── Load existing project ──────────────────────────────────────────────────────
const loadProject = async () => {
  if (!isEdit.value) return
  fetching.value = true
  try {
    const { data } = await api.get(`/api/v1/projects/getAll?page=0&size=200`)
    const all = data.data.content
    const found = all.find(p => String(p.id) === String(route.params.id))
    if (found) applyProject(found)
  } catch (e) {
    showToast('error', 'داتا هێنان سەرنەکەوت: ' + (e?.response?.data?.message || e.message))
  } finally { fetching.value = false }
}

const applyProject = (p) => {
  form.contentLanguages = [...(p.contentLanguages || ['CKB'])]
  activeLang.value = form.contentLanguages[0] || 'CKB'
  form.coverUrl       = p.coverUrl || ''
  form.projectTypeCkb = p.projectTypeCkb || ''
  form.projectTypeKmr = p.projectTypeKmr || ''
  form.status         = p.status || 'ONGOING'
  form.projectDate    = p.projectDate || ''
  if (p.ckbContent) Object.assign(form.ckbContent, p.ckbContent)
  if (p.kmrContent) Object.assign(form.kmrContent, p.kmrContent)
  form.contentsCkb = [...(p.contentsCkb || [])]; form.contentsKmr = [...(p.contentsKmr || [])]
  form.tagsCkb     = [...(p.tagsCkb || [])];     form.tagsKmr     = [...(p.tagsKmr || [])]
  form.keywordsCkb = [...(p.keywordsCkb || [])];  form.keywordsKmr = [...(p.keywordsKmr || [])]
  form.media = (p.media || []).map(m => ({
    mediaType: m.mediaType || 'IMAGE', url: m.url || '', externalUrl: m.externalUrl || '',
    embedUrl: m.embedUrl || '', caption: m.caption || '', sortOrder: m.sortOrder ?? 0,
  }))
}

// ── Cover ────────────────────────────────────────────────────────────────────
const onCoverFile = (e) => { const f = e.target.files?.[0]; if (!f) return; coverFile.value = f; coverPreview.value = URL.createObjectURL(f); form.coverUrl = '' }
const removeCover = () => { coverFile.value = null; coverPreview.value = ''; form.coverUrl = '' }

// ── Media files ───────────────────────────────────────────────────────────────
const onMediaFiles  = (e) => { newMediaFiles.value.push(...Array.from(e.target.files)) }
const onDrop        = (e) => { dragOver.value = false; newMediaFiles.value.push(...Array.from(e.dataTransfer.files)) }
const removeNewFile = (i) => { newMediaFiles.value.splice(i, 1) }
const addMediaItem  = () => { form.media.push({ mediaType: 'IMAGE', url: '', externalUrl: '', embedUrl: '', caption: '', sortOrder: form.media.length }) }
const removeMedia   = (i) => { form.media.splice(i, 1) }

// ── Validation ────────────────────────────────────────────────────────────────
const validate = () => {
  const e = {}
  if (!form.contentLanguages.length) e.contentLanguages = 'کەمی یەک زمانیکی هەڵبژێرە'
  if (form.contentLanguages.includes('CKB')) {
    if (!form.ckbContent.title.trim())  e.ckbTitle       = 'ناونیشانی سۆرانی پێویستە'
    if (!form.projectTypeCkb.trim())    e.projectTypeCkb = 'جۆری پڕۆژە (سۆرانی) پێویستە'
  }
  if (form.contentLanguages.includes('KMR')) {
    if (!form.kmrContent.title.trim())  e.kmrTitle       = 'ناونیشانی کورمانجی پێویستە'
    if (!form.projectTypeKmr.trim())    e.projectTypeKmr = 'جۆری پڕۆژە (کورمانجی) پێویستە'
  }
  if (!coverFile.value && !form.coverUrl.trim()) e.cover = 'کڤەر پێویستە — فایل بار بکە یان URL بنووسە'
  errors.value = e
  return !Object.keys(e).length
}

// ── Submit ────────────────────────────────────────────────────────────────────
const submit = async () => {
  if (!validate()) { window.scrollTo({ top: 0, behavior: 'smooth' }); return }
  saving.value = true
  const fd = new FormData()
  const dto = {
    contentLanguages: form.contentLanguages,
    coverUrl: form.coverUrl || null,
    projectTypeCkb: form.contentLanguages.includes('CKB') ? form.projectTypeCkb : null,
    projectTypeKmr: form.contentLanguages.includes('KMR') ? form.projectTypeKmr : null,
    status: form.status,
    projectDate: form.projectDate || null,
    ckbContent: form.contentLanguages.includes('CKB') ? form.ckbContent : null,
    kmrContent: form.contentLanguages.includes('KMR') ? form.kmrContent : null,
    contentsCkb: form.contentsCkb, contentsKmr: form.contentsKmr,
    tagsCkb: form.tagsCkb, tagsKmr: form.tagsKmr,
    keywordsCkb: form.keywordsCkb, keywordsKmr: form.keywordsKmr,
    media: form.media.filter(m => m.url || m.externalUrl || m.embedUrl),
  }
  fd.append('data', new Blob([JSON.stringify(dto)], { type: 'application/json' }))
  if (coverFile.value) fd.append('cover', coverFile.value)
  newMediaFiles.value.forEach(f => fd.append('media', f))
  try {
    let url, method
    if (isEdit.value) { url = `/api/v1/projects/update/${route.params.id}/with-files`; method = 'put' }
    else { url = `/api/v1/projects/with-files`; method = 'post' }
    await api[method](url, fd, { headers: { 'Content-Type': 'multipart/form-data' } })
    showToast('success', isEdit.value ? 'پڕۆژەکە نوێکرایەوە ✓' : 'پڕۆژەکە دروستکرا ✓')
    setTimeout(() => router.push('/admin/projects'), 1200)
  } catch (e) {
    showToast('error', e?.response?.data?.message || e.message || 'هەڵەیەک ڕوویدا')
  } finally { saving.value = false }
}

const doDelete = async () => {
  if (!confirm(`دڵنیای لە سڕینەوەی پڕۆژە #${route.params.id}؟`)) return
  try {
    await api.delete(`/api/v1/projects/delete/${route.params.id}`)
    showToast('success', 'پڕۆژەکە سڕایەوە')
    setTimeout(() => router.push('/admin/projects'), 800)
  } catch (e) { showToast('error', e?.response?.data?.message || 'سڕینەوە سەرنەکەوت') }
}

const showToast = (type, msg) => {
  toast.value = { show: true, type, msg }
  setTimeout(() => { toast.value.show = false }, 4000)
}

onMounted(loadProject)
</script>

<style scoped>
.ped { direction: rtl; max-width: 1280px; margin: 0 auto; }
.ped__head { display: flex; align-items: center; gap: 1.25rem; margin-bottom: 1.5rem; flex-wrap: wrap; }
.ped__back { display: inline-flex; align-items: center; gap: .4rem; color: var(--muted); text-decoration: none; font-weight: 600; font-size: .87rem; padding: .4rem .7rem; border-radius: 8px; border: 1px solid var(--border); background: var(--white); transition: var(--transition); }
.ped__back:hover { color: var(--crimson); border-color: var(--crimson); }
.ped__title { font-size: 1.4rem; font-weight: 700; color: var(--text); }
.ped__sub { font-size: .8rem; color: var(--muted); margin-top: .1rem; }
.toast { display: flex; align-items: center; gap: .65rem; padding: .8rem 1.1rem; border-radius: var(--radius-sm); font-weight: 600; font-size: .88rem; margin-bottom: 1rem; }
.toast__ico { font-size: 1rem; }
.toast--success { background: rgba(25,130,80,.1); border: 1px solid rgba(25,130,80,.25); color: #186048; }
.toast--error { background: rgba(180,40,40,.08); border: 1px solid rgba(180,40,40,.2); color: var(--crimson); }
.toast-enter-active, .toast-leave-active { transition: .3s ease; }
.toast-enter-from, .toast-leave-to { opacity: 0; transform: translateY(-6px); }
.loading-bar { height: 3px; border-radius: 2px; margin-bottom: .75rem; background: linear-gradient(90deg, var(--crimson), var(--gold), var(--crimson)); background-size: 200% 100%; animation: shimmer 1.2s linear infinite; }
@keyframes shimmer { 0% { background-position: 200% 0 } 100% { background-position: -200% 0 } }
.ped__layout { display: grid; grid-template-columns: 1fr 320px; gap: 1.25rem; align-items: start; }
@media (max-width: 900px) { .ped__layout { grid-template-columns: 1fr; } }
.card { background: var(--white); border: 1px solid var(--border); border-radius: var(--radius-md); padding: 1.35rem; box-shadow: var(--shadow-sm); margin-bottom: 1.25rem; }
.card--danger { border-color: rgba(140,21,21,.18); }
.card__hd { display: flex; align-items: center; gap: .6rem; font-weight: 700; font-size: .95rem; color: var(--text); margin-bottom: 1.1rem; padding-bottom: .75rem; border-bottom: 1px solid var(--cream-dk); }
.card__hd--danger { color: var(--crimson); border-bottom-color: rgba(140,21,21,.1); }
.card__hd-ico { font-size: 1rem; }
.card__hd-badge { margin-right: auto; background: var(--cream-dk); border: 1px solid var(--border); border-radius: 99px; padding: .1rem .6rem; font-size: .78rem; color: var(--muted); }
.danger-text { font-size: .84rem; color: var(--muted); margin-bottom: .85rem; line-height: 1.65; }
.lang-picks { display: flex; gap: .75rem; flex-wrap: wrap; }
.lang-pick { display: inline-flex; align-items: center; gap: .5rem; padding: .65rem 1rem; border-radius: var(--radius-sm); border: 1.5px solid var(--border); cursor: pointer; transition: var(--transition); font-weight: 600; user-select: none; }
.lang-pick input { display: none; }
.lang-pick:hover { border-color: var(--crimson); }
.lang-pick--on { background: rgba(140,21,21,.06); border-color: var(--crimson); color: var(--crimson); }
.lang-pick__code { font-size: .75rem; font-weight: 700; opacity: .6; }
.tabs { display: flex; gap: .4rem; margin-bottom: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 0; }
.tab { display: inline-flex; align-items: center; gap: .4rem; padding: .6rem 1rem; border-radius: 8px 8px 0 0; border: 1px solid transparent; border-bottom: none; background: none; color: var(--muted); font-weight: 700; font-size: .88rem; cursor: pointer; transition: var(--transition); margin-bottom: -1px; font-family: inherit; }
.tab--on { background: var(--white); border-color: var(--border); color: var(--crimson); }
.tab__pip { width: 7px; height: 7px; border-radius: 50%; }
.tab__pip--ckb { background: #c8a800; }
.tab__pip--kmr { background: #4a7af0; }
.tab-panel { padding-top: .25rem; }
.field { display: flex; flex-direction: column; gap: .4rem; margin-bottom: .95rem; }
.lbl { font-weight: 700; font-size: .83rem; color: var(--text); }
.lbl--req::after { content: ' *'; color: var(--crimson); }
.inp { border: 1.5px solid var(--border); border-radius: var(--radius-sm); padding: .7rem .9rem; background: var(--cream); color: var(--text); font-size: .9rem; outline: none; transition: var(--transition); width: 100%; font-family: inherit; }
.inp:focus { background: var(--white); border-color: var(--crimson); box-shadow: 0 0 0 3px rgba(140,21,21,.1); }
.inp--err { border-color: #c0392b; }
.inp--sm { padding: .5rem .7rem; font-size: .85rem; }
.ta { min-height: 130px; resize: vertical; }
.err { font-size: .78rem; color: #c0392b; font-weight: 600; }
.status-toggle { display: grid; grid-template-columns: 1fr 1fr; gap: .6rem; }
.status-btn { display: flex; align-items: center; justify-content: center; gap: .55rem; padding: .75rem .9rem; border-radius: var(--radius-sm); border: 1.5px solid var(--border); background: var(--cream); color: var(--muted); font-weight: 700; font-size: .88rem; cursor: pointer; transition: var(--transition); font-family: inherit; }
.status-btn:hover { border-color: var(--crimson); color: var(--text); }
.status-btn__dot { width: 9px; height: 9px; border-radius: 50%; flex-shrink: 0; }
.status-btn__dot--ongoing { background: #f39c12; box-shadow: 0 0 6px rgba(243,156,18,.6); }
.status-btn__dot--completed { background: #27ae60; box-shadow: 0 0 6px rgba(39,174,96,.6); }
.status-btn--on.status-btn--ongoing { background: rgba(243,156,18,.08); border-color: #f39c12; color: #b37a00; box-shadow: 0 0 0 3px rgba(243,156,18,.12); }
.status-btn--on.status-btn--completed { background: rgba(39,174,96,.08); border-color: #27ae60; color: #186040; box-shadow: 0 0 0 3px rgba(39,174,96,.12); }
.cover-preview { position: relative; border-radius: var(--radius-sm); overflow: hidden; border: 1px solid var(--border); margin-bottom: .75rem; }
.cover-preview img { width: 100%; max-height: 200px; object-fit: cover; display: block; }
.cover-preview__remove { position: absolute; top: .5rem; left: .5rem; width: 28px; height: 28px; border-radius: 50%; background: rgba(0,0,0,.55); color: #fff; border: none; cursor: pointer; font-size: .85rem; display: flex; align-items: center; justify-content: center; }
.upload-zone { border: 2px dashed var(--border); border-radius: var(--radius-sm); cursor: pointer; transition: var(--transition); display: block; margin-bottom: .75rem; }
.upload-zone:hover, .upload-zone--over { border-color: var(--crimson); background: rgba(140,21,21,.03); }
.upload-zone--sm .upload-zone__inner { padding: 1.25rem; }
.upload-zone__inner { display: flex; flex-direction: column; align-items: center; gap: .5rem; padding: 1.75rem 1rem; color: var(--muted); font-size: .87rem; text-align: center; cursor: pointer; }
.upload-zone__hint { font-size: .76rem; opacity: .7; }
.media-list { display: flex; flex-direction: column; gap: .75rem; margin-bottom: 1rem; }
.media-item { border: 1px solid var(--border); border-radius: var(--radius-sm); padding: .85rem; background: var(--cream); }
.media-item__top { display: flex; align-items: center; gap: .5rem; margin-bottom: .6rem; }
.media-item__del { margin-right: auto; width: 26px; height: 26px; border-radius: 6px; background: none; border: 1px solid var(--border); color: var(--muted); cursor: pointer; display: flex; align-items: center; justify-content: center; transition: var(--transition); }
.media-item__del:hover { background: rgba(140,21,21,.08); border-color: var(--crimson); color: var(--crimson); }
.media-item__fields { display: grid; grid-template-columns: 1fr 1fr; gap: .5rem; }
@media (max-width: 600px) { .media-item__fields { grid-template-columns: 1fr; } }
.file-list { display: flex; flex-wrap: wrap; gap: .4rem; margin-bottom: .75rem; }
.file-chip { display: inline-flex; align-items: center; gap: .4rem; padding: .3rem .65rem; border-radius: 6px; background: var(--cream-dk); border: 1px solid var(--border); font-size: .78rem; color: var(--muted); }
.file-chip button { background: none; border: none; cursor: pointer; color: var(--muted); font-size: .75rem; }
.file-chip button:hover { color: var(--crimson); }
.sel { padding: .5rem .7rem; border: 1.5px solid var(--border); border-radius: var(--radius-sm); background: var(--white); color: var(--text); font-size: .88rem; outline: none; cursor: pointer; transition: var(--transition); font-family: inherit; }
.sel:focus { border-color: var(--crimson); }
.sel--sm { font-size: .83rem; }
.btn { display: inline-flex; align-items: center; justify-content: center; gap: .45rem; padding: .7rem 1.1rem; border-radius: var(--radius-sm); font-weight: 700; font-size: .88rem; cursor: pointer; border: 1px solid transparent; transition: var(--transition); text-decoration: none; white-space: nowrap; font-family: inherit; }
.btn--primary { background: var(--crimson); color: #fff; box-shadow: 0 6px 20px rgba(140,21,21,.25); }
.btn--primary:hover { background: var(--crimson-lt); transform: translateY(-1px); }
.btn--ghost { background: transparent; border-color: var(--border); color: var(--text); }
.btn--ghost:hover { border-color: var(--crimson); color: var(--crimson); }
.btn--outline { background: transparent; border-color: var(--border); color: var(--muted); }
.btn--outline:hover { border-color: var(--crimson); color: var(--crimson); }
.btn--danger { background: #c0392b; color: #fff; border-color: #c0392b; }
.btn--danger:hover { background: #a93226; }
.btn--sm { padding: .5rem .8rem; font-size: .83rem; }
.btn--full { width: 100%; }
.btn:disabled { opacity: .55; cursor: not-allowed; transform: none !important; }
.side-actions { display: flex; flex-direction: column; gap: .6rem; }
.spinner { width: 14px; height: 14px; border: 2px solid rgba(255,255,255,.4); border-top-color: #fff; border-radius: 50%; animation: spin .7s linear infinite; }
@keyframes spin { to { transform: rotate(360deg) } }
</style>

<!-- Tag Input global styles -->
<style>
.tag-input { display: flex; flex-direction: column; gap: .4rem; }
.tag-input__tags { display: flex; flex-wrap: wrap; gap: .4rem; align-items: center; border: 1.5px solid var(--border); border-radius: var(--radius-sm); padding: .45rem .65rem; background: var(--cream); min-height: 42px; transition: border-color .2s; }
.tag-input__tags:focus-within { border-color: var(--crimson); background: var(--white); box-shadow: 0 0 0 3px rgba(140,21,21,.1); }
.tag-input__tag { display: inline-flex; align-items: center; gap: .3rem; padding: .2rem .55rem; border-radius: 6px; font-size: .8rem; font-weight: 600; }
.tag-input__tag--default { background: var(--cream-dk); border: 1px solid var(--border); color: var(--text); }
.tag-input__tag--gold { background: rgba(254,221,0,.2); border: 1px solid rgba(254,221,0,.4); color: #807000; }
.tag-input__tag--blue { background: rgba(30,80,200,.1); border: 1px solid rgba(30,80,200,.2); color: #1840a0; }
.tag-input__tag button { background: none; border: none; cursor: pointer; color: inherit; opacity: .6; font-size: .75rem; line-height: 1; }
.tag-input__tag button:hover { opacity: 1; }
.tag-input__inp { border: none; outline: none; background: none; font-family: inherit; font-size: .88rem; min-width: 120px; color: var(--text); }
</style>