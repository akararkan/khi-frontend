<template>
  <main id="main-content" class="home" :dir="lang.dir" :class="{ 'home--ltr': lang.isKMR }">

    <!-- ══════════════════════════════════════════════════════ HERO ══ -->
    <section class="hero" aria-label="Hero">
      <div class="hero__slides" ref="heroBgRef">
        <div v-for="(slide,i) in heroSlides" :key="i"
          class="hero__slide" :class="{'hero__slide--active': i===heroSlideIndex}"
          :style="{backgroundImage:`url(${slide.url})`}" />
        <div class="hero__slide hero__slide--gradient" :class="{'hero__slide--active':!heroSlides.length}" />
      </div>
      <div class="hero__overlay" />
      <div class="hero__noise" />
      <div class="hero__particles">
        <span v-for="i in 18" :key="i" class="particle" :style="particleStyle(i)" />
      </div>
      <div class="container hero__content" data-animate="fade-up">
        <div class="hero__kicker">
          <span class="hero__line" /><span class="hero__est">est. 1992</span><span class="hero__line" />
        </div>
        <h1 class="hero__title">
          <span class="hero__title-sm">{{ lbl('heroKicker') }}</span>
          <span class="hero__title-lg">{{ lbl('heroMain') }}</span>
        </h1>
        <p class="hero__desc">{{ lbl('heroDesc') }}</p>
        <div class="hero__actions">
          <button class="btn btn--hero" @click="scrollTo('#spotlight')">
            <span>{{ lbl('exploreNews') }}</span>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 17L17 7M17 7H7M17 7V17"/></svg>
          </button>
          <button class="btn btn--glass" @click="scrollTo('#publications')">
            <span>{{ lbl('publications') }}</span>
          </button>
          <button class="btn btn--ghost" @click="scrollTo('#memories')">
            <span>💫 {{ lbl('albumMemories') }}</span>
          </button>
        </div>
        <div class="hero__stats">
          <div v-for="(s,i) in heroStats" :key="i" class="hstat">
            <span class="hstat__num" :class="{'hstat__num--loading':statsLoading}">{{ statsLoading ? '—' : s.value }}</span>
            <span class="hstat__label">{{ s.label }}</span>
          </div>
        </div>
      </div>
      <div class="hero__dots" v-if="heroSlides.length>1">
        <button v-for="(_,i) in heroSlides" :key="i" class="hero__dot"
          :class="{'hero__dot--active':i===heroSlideIndex}" @click="goToSlide(i)" />
      </div>
      <button class="scroll-cue" @click="scrollTo('#about')">
        <span class="scroll-cue__line" /><span class="scroll-cue__label">{{ lbl('scrollDown') }}</span>
      </button>
    </section>

    <!-- ══════════════════════════════════════════════════════ ABOUT ══ -->
    <section class="section section--about" id="about">
      <div class="container">
        <div class="about" data-animate="fade-up">
          <div class="about__text-col">
            <span class="label-tag">{{ lbl('aboutBadge') }}</span>
            <h2 class="about__title">{{ lbl('aboutTitle') }}</h2>
            <div class="about__rule" />
            <p class="about__lead">{{ lbl('aboutLead') }}</p>
            <p class="about__body">{{ lbl('aboutText') }}</p>
            <div class="about__btns">
              <button class="btn btn--primary" @click="go('/about')">{{ lbl('learnMore') }} <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></button>
              <button class="btn btn--outline" @click="go('/contact')">{{ lbl('contactUs') }}</button>
            </div>
          </div>
          <div class="about__pillars">
            <div v-for="p in aboutPillars" :key="p.icon" class="pillar">
              <span class="pillar__icon">{{ p.icon }}</span>
              <h3 class="pillar__title">{{ p.title }}</h3>
              <p class="pillar__sub">{{ p.sub }}</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════ NEWS ══ -->
    <section id="spotlight" class="section section--cream">
      <div class="container">
        <header class="sec-header" data-animate="fade-up">
          <span class="label-tag">{{ lbl('newsBadge') }}</span>
          <h2 class="sec-title">{{ lbl('newsTitle') }}</h2>
          <p class="sec-sub">{{ lbl('newsDesc') }}</p>
        </header>
        <div v-if="newsLoading" class="news-skel-grid">
          <div v-for="i in 4" :key="i" class="skel" :style="{'--d':`${(i-1)*.08}s`}">
            <div class="skel__img shimmer"/><div class="skel__body"><div class="skel__line shimmer" style="width:40%"/><div class="skel__line shimmer" style="width:88%;margin-top:.5rem"/></div>
          </div>
        </div>
        <div v-else-if="!displayedNews.length" class="empty-block"><span>📰</span><p>{{ lbl('noContent') }}</p></div>
        <template v-else>
          <div class="news-layout">
            <article class="news-feat" data-animate="fade-up" @click="openNewsModal(displayedNews[0])">
              <div class="news-feat__inner">
                <img :src="safeImg(displayedNews[0].coverUrl)||fallback" :alt="nTitle(displayedNews[0])" loading="lazy" @error="onImgErr"/>
                <div class="news-feat__grad"/>
                <div class="news-feat__meta">
                  <span class="nbadge">{{ nCat(displayedNews[0]) }}</span>
                  <time class="news-feat__date">{{ formatDate(displayedNews[0].datePublished) }}</time>
                </div>
                <div class="news-feat__footer">
                  <h2 class="news-feat__title">{{ nTitle(displayedNews[0]) }}</h2>
                  <p class="news-feat__excerpt">{{ truncate(nDesc(displayedNews[0]),140) }}</p>
                  <span class="read-more">{{ lbl('readMore') }} ←</span>
                </div>
              </div>
            </article>
            <div class="news-stack">
              <article v-for="(item,idx) in displayedNews.slice(1,4)" :key="item.id"
                class="news-row" data-animate="fade-up" :data-delay="`${idx*90}ms`"
                @click="openNewsModal(item)">
                <div class="news-row__img">
                  <img :src="safeImg(item.coverUrl)||fallback" :alt="nTitle(item)" loading="lazy" @error="onImgErr"/>
                </div>
                <div class="news-row__body">
                  <span class="nbadge nbadge--sm">{{ nCat(item) }}</span>
                  <h3 class="news-row__title">{{ nTitle(item) }}</h3>
                  <p class="news-row__excerpt">{{ truncate(nDesc(item),75) }}</p>
                  <time class="news-row__date">{{ formatDate(item.datePublished) }}</time>
                </div>
              </article>
            </div>
          </div>
        </template>
        <div class="sec-footer" data-animate="fade-up">
          <button class="btn btn--outline" @click="go('/news')">{{ lbl('allNews') }} <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></button>
        </div>
      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════ PUBLICATIONS ══ -->
    <section class="section section--dark" id="publications">
      <div class="container">
        <header class="sec-header sec-header--light" data-animate="fade-up">
          <span class="label-tag label-tag--dim">{{ lbl('pubBadge') }}</span>
          <h2 class="sec-title">{{ lbl('pubTitle') }}</h2>
          <p class="sec-sub sec-sub--dim">{{ lbl('pubDesc') }}</p>
        </header>

        <div v-if="pubLoading" class="pub-skel-grid">
          <div v-for="i in 4" :key="i" class="skel skel--dark" :style="{'--d':`${(i-1)*.07}s`}">
            <div class="skel__img shimmer shimmer--dark"/><div class="skel__body"><div class="skel__line shimmer shimmer--dark" style="width:50%"/></div>
          </div>
        </div>

        <template v-else>
          <!-- ─── SOUND ─── -->
          <div v-if="sounds.length" class="pub-chapter" data-animate="fade-up">
            <div class="chapter-head">
              <div class="chapter-head__l">
                <span class="chapter-num">01</span>
                <div>
                  <h3 class="chapter-title">{{ lbl('sound') }}</h3>
                  <p class="chapter-sub">{{ lbl('soundDesc') }}</p>
                </div>
              </div>
              <button class="btn-link" @click="go('/publishments')">{{ lbl('viewAll') }}</button>
            </div>
            <div v-if="singleTracks.length" class="sound-block">
              <div class="sub-label">{{ lbl('singleTracks') }}</div>
              <div class="player-list">
                <div v-for="(t,idx) in singleTracks.slice(0,3)" :key="t.id"
                  class="player-row" data-animate="fade-up" :data-delay="`${idx*55}ms`"
                  @click="go('/publishments')">
                  <span class="player-row__idx">{{ String(idx+1).padStart(2,'0') }}</span>
                  <div class="player-row__art">
                    <img :src="pCover(t)" :alt="pTitle(t)" @error="onImgErr" loading="lazy"/>
                    <div class="player-row__hover"><span>▶</span></div>
                  </div>
                  <div class="player-row__info">
                    <span class="player-row__title">{{ pTitle(t) }}</span>
                    <span class="player-row__artist" v-if="pWriter(t)">{{ pWriter(t) }}</span>
                  </div>
                  <div class="player-row__dur" v-if="t.files?.[0]?.durationSeconds">{{ formatTime(t.files[0].durationSeconds) }}</div>
                  <div class="player-row__eq"><span v-for="b in 5" :key="b" class="eq-bar" :style="{'--b':b}"/></div>
                </div>
              </div>
            </div>
            <div v-if="soundGalleries.length" class="sound-block" style="margin-top:24px">
              <div class="sub-label">{{ lbl('soundGalleries') }}</div>
              <div class="album-row-flex">
                <article v-for="(item,idx) in soundGalleries.slice(0,3)" :key="item.id"
                  class="album-card" data-animate="fade-up" :data-delay="`${idx*65}ms`"
                  @click="go('/publishments')">
                  <div class="album-card__stack">
                    <div class="alb-sh2"/><div class="alb-sh1"/>
                    <div class="alb-front">
                      <img :src="pCover(item)" :alt="pTitle(item)" @error="onImgErr" loading="lazy"/>
                      <div class="alb-shine"/>
                    </div>
                  </div>
                  <div class="album-card__info">
                    <span class="album-card__title">{{ pTitle(item) }}</span>
                    <span class="album-card__cnt" v-if="item.files?.length">{{ item.files.length }} {{ lbl('tracks') }}</span>
                  </div>
                </article>
              </div>
            </div>
          </div>

          <!-- ─── VIDEO ─── -->
          <div v-if="videos.length" class="pub-chapter" data-animate="fade-up">
            <div class="chapter-head">
              <div class="chapter-head__l">
                <span class="chapter-num">02</span>
                <div>
                  <h3 class="chapter-title">{{ lbl('video') }}</h3>
                  <p class="chapter-sub">{{ lbl('videoDesc') }}</p>
                </div>
              </div>
              <button class="btn-link" @click="go('/publishments')">{{ lbl('viewAll') }}</button>
            </div>
            <div class="film-strip">
              <article v-for="(item,idx) in videos.slice(0,4)" :key="item.id"
                class="film-card" data-animate="fade-up" :data-delay="`${idx*60}ms`"
                @click="go('/publishments')">
                <div class="film-card__thumb">
                  <img :src="pCover(item)" :alt="pTitle(item)" loading="lazy" @error="onImgErr"/>
                  <div class="film-card__grain"/>
                  <div class="film-card__grad"/>
                  <div class="film-card__play-layer"><div class="play-btn">▶</div></div>
                  <div class="film-card__dur" v-if="item.durationSeconds">{{ formatTime(item.durationSeconds) }}</div>
                  <div v-if="item.albumOfMemories" class="film-card__mem">💫</div>
                  <div class="film-perfs film-perfs--t"/><div class="film-perfs film-perfs--b"/>
                </div>
                <div class="film-card__body">
                  <span class="film-card__type">{{ item.videoType || lbl('video') }}</span>
                  <h3 class="film-card__title">{{ pTitle(item) }}</h3>
                  <p class="film-card__desc">{{ truncate(pDesc(item),60) }}</p>
                </div>
              </article>
            </div>
          </div>

          <!-- ─── WRITING ─── -->
          <div v-if="writings.length" class="pub-chapter" data-animate="fade-up">
            <div class="chapter-head">
              <div class="chapter-head__l">
                <span class="chapter-num">03</span>
                <div>
                  <h3 class="chapter-title">{{ lbl('writings') }}</h3>
                  <p class="chapter-sub">{{ lbl('writingDesc') }}</p>
                </div>
              </div>
              <button class="btn-link" @click="go('/publishments')">{{ lbl('viewAll') }}</button>
            </div>
            <div class="shelf">
              <article v-for="(item,idx) in writings.slice(0,4)" :key="item.id"
                class="book-card" data-animate="fade-up" :data-delay="`${idx*65}ms`"
                @click="go('/publishments')">
                <div class="book-card__cover">
                  <img :src="pCover(item)" :alt="pTitle(item)" loading="lazy" @error="onImgErr"/>
                  <div class="book-card__spine"/><div class="book-card__shine"/>
                  <div class="book-card__pages"/>
                  <div class="book-card__hover"><span>{{ lbl('read') }}</span></div>
                </div>
                <div class="book-card__meta">
                  <h3 class="book-card__title">{{ pTitle(item) }}</h3>
                  <span class="book-card__author" v-if="pWriter(item)">{{ pWriter(item) }}</span>
                  <span class="book-card__pg" v-if="item.ckbContent?.pageCount||item.kmrContent?.pageCount">{{ item.ckbContent?.pageCount||item.kmrContent?.pageCount }} {{ lbl('pages') }}</span>
                </div>
              </article>
            </div>
          </div>

          <!-- ─── IMAGE GALLERY ─── -->
          <div v-if="imageCollections.length" class="pub-chapter" data-animate="fade-up">
            <div class="chapter-head">
              <div class="chapter-head__l">
                <span class="chapter-num">04</span>
                <div>
                  <h3 class="chapter-title">{{ lbl('images') }}</h3>
                  <p class="chapter-sub">{{ lbl('imageDesc') }}</p>
                </div>
              </div>
              <button class="btn-link" @click="go('/publishments')">{{ lbl('viewAll') }}</button>
            </div>
            <div class="editorial-grid">
              <article v-for="(item,idx) in imageCollections.slice(0,5)" :key="item.id"
                class="ed-cell" :class="`ed-cell--${idx}`"
                data-animate="fade-up" :data-delay="`${idx*55}ms`"
                @click="openImageLightbox(item)">
                <img :src="pCover(item)" :alt="pTitle(item)" loading="lazy" @error="onImgErr"/>
                <div class="ed-cell__grad"/>
                <div class="ed-cell__cnt" v-if="item.imageAlbum?.length">🖼 {{ item.imageAlbum.length }}</div>
                <div class="ed-cell__info">
                  <span class="ed-cell__cat">{{ item.collectionType||lbl('images') }}</span>
                  <h3 class="ed-cell__title">{{ pTitle(item) }}</h3>
                </div>
              </article>
            </div>
          </div>
        </template>

        <div class="sec-footer" data-animate="fade-up">
          <button class="btn btn--glass" @click="go('/publishments')">{{ lbl('allPubs') }} <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></button>
        </div>
      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════ PROJECTS ══ -->
    <section class="section" id="projects">
      <div class="container">
        <header class="sec-header" data-animate="fade-up">
          <span class="label-tag">{{ lbl('projBadge') }}</span>
          <h2 class="sec-title">{{ lbl('projTitle') }}</h2>
          <p class="sec-sub">{{ lbl('projDesc') }}</p>
        </header>
        <div class="filter-bar" data-animate="fade-up">
          <button v-for="f in projFilterDefs" :key="f.val"
            class="fchip" :class="{'fchip--on':projFilter===f.val}"
            @click="projFilter=f.val">{{ f.label }}</button>
        </div>
        <div v-if="projLoading" class="proj-grid">
          <div v-for="i in 3" :key="i" class="skel" :style="{'--d':`${(i-1)*.07}s`}">
            <div class="skel__img shimmer" style="aspect-ratio:16/10"/><div class="skel__body"><div class="skel__line shimmer" style="width:55%"/></div>
          </div>
        </div>
        <div v-else-if="!filteredProjects.length" class="empty-block">
          <span>📂</span><p>{{ lbl('noContent') }}</p>
          <button class="btn btn--outline" @click="projFilter='all'" style="margin-top:16px">{{ lbl('reset') }}</button>
        </div>
        <TransitionGroup v-else name="grid-fade" tag="div" class="proj-grid">
          <article v-for="(proj,idx) in filteredProjects.slice(0,3)" :key="proj.id"
            class="proj-card" data-animate="fade-up" :data-delay="`${idx*90}ms`"
            @click="go('/projects')">
            <div class="proj-card__img">
              <img :src="safeImg(proj.coverUrl)||fallback" :alt="projTitle(proj)" loading="lazy" @error="onImgErr"/>
              <div class="proj-card__badge" :class="proj.status==='COMPLETED'?'proj-card__badge--done':'proj-card__badge--live'">{{ proj.status==='COMPLETED'?lbl('completed'):lbl('ongoing') }}</div>
            </div>
            <div class="proj-card__body">
              <h3 class="proj-card__title">{{ projTitle(proj) }}</h3>
              <p class="proj-card__text">{{ truncate(projDesc(proj),110) }}</p>
              <div class="proj-card__tags" v-if="projTags(proj).length">
                <span v-for="t in projTags(proj).slice(0,3)" :key="t" class="ptag">#{{ t }}</span>
              </div>
              <span class="card-cta">{{ lbl('viewProject') }} <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
            </div>
          </article>
        </TransitionGroup>
        <div class="sec-footer" data-animate="fade-up">
          <button class="btn btn--primary" @click="go('/projects')">{{ lbl('allProjects') }} <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></button>
        </div>
      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════ MEMORIES ══ -->
    <section class="section section--memories" id="memories">
      <div class="mem-bg">
        <div class="mem-orb mem-orb--a"/><div class="mem-orb mem-orb--b"/>
        <div class="mem-lines"/>
      </div>
      <div class="container" style="position:relative;z-index:2">
        <header class="sec-header sec-header--light" data-animate="fade-up">
          <span class="label-tag label-tag--mem">💫 {{ lbl('memBadge') }}</span>
          <h2 class="sec-title">{{ lbl('memTitle') }}</h2>
          <p class="sec-sub sec-sub--dim">{{ lbl('memDesc') }}</p>
        </header>
        <div class="mem-filter" data-animate="fade-up">
          <button v-for="f in memFilterDefs" :key="f.val" class="mchip"
            :class="{'mchip--on':memFilter===f.val}" @click="memFilter=f.val">{{ f.icon }} {{ f.label }}</button>
        </div>
        <div v-if="memLoading" class="mem-grid">
          <div v-for="i in 6" :key="i" class="skel skel--dark" :style="{'--d':`${(i-1)*.06}s`}">
            <div class="skel__img shimmer shimmer--dark" style="aspect-ratio:4/3"/>
          </div>
        </div>
        <div v-else-if="!filteredMemories.length" class="empty-block empty-block--light"><span>💫</span><p>{{ lbl('noContent') }}</p></div>
        <div v-else class="mem-grid">
          <article v-for="(mem,idx) in filteredMemories.slice(0,6)" :key="`m-${mem._mtype}-${mem.id}`"
            class="mem-card" data-animate="fade-up" :data-delay="`${idx*80}ms`"
            @click="go('/publishments')">
            <div class="mem-card__media">
              <img :src="memCover(mem)" :alt="memTitle(mem)" loading="lazy" @error="onImgErr"/>
              <div class="mem-card__film"/><div class="mem-card__grad"/>
              <div class="mem-card__top">
                <span class="mem-pill">{{ mem._mtype==='sound'?'🎵':'🎬' }} {{ mem._mtype==='sound'?lbl('sound'):lbl('video') }}</span>
                <span class="mem-star">💫</span>
              </div>
              <div class="mem-card__wave" v-if="mem._mtype==='sound'&&mem.files?.length">
                <span v-for="b in 5" :key="b" class="wbar" :style="{'--b':b}"/>
              </div>
              <div class="mem-card__foot">
                <h3 class="mem-card__title">{{ memTitle(mem) }}</h3>
                <p class="mem-card__sub">{{ truncate(memDesc(mem),55) }}</p>
                <div class="mem-card__pills">
                  <span v-if="mem.files?.length">🎵 {{ mem.files.length }} {{ lbl('tracks') }}</span>
                  <span v-if="mem.durationSeconds">⏱ {{ formatTime(mem.durationSeconds) }}</span>
                </div>
              </div>
            </div>
          </article>
        </div>
        <div class="sec-footer" data-animate="fade-up">
          <button class="btn btn--glass-mem" @click="go('/publishments')">{{ lbl('allMemories') }} <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></button>
        </div>
      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════ DONATE ══ -->
    <section class="section section--donate" id="donate">
      <div class="donate-glow donate-glow--a"/><div class="donate-glow donate-glow--b"/>
      <div class="container">
        <div class="donate-wrap" data-animate="fade-up">
          <div class="donate-copy">
            <span class="donate-eyebrow">❤ {{ lbl('donateBadge') }}</span>
            <h2 class="donate-title">{{ lbl('donateTitle') }}</h2>
            <p class="donate-lead">{{ lbl('donateLead') }}</p>
            <ul class="donate-reasons">
              <li><span class="dr-ico">🎵</span>{{ lbl('donateR1') }}</li>
              <li><span class="dr-ico">📚</span>{{ lbl('donateR2') }}</li>
              <li><span class="dr-ico">🏛</span>{{ lbl('donateR3') }}</li>
            </ul>
            <div class="donate-amounts">
              <button v-for="a in [10,25,50,100]" :key="a"
                class="damount" :class="{'damount--on':selectedAmt===a}"
                @click="selectedAmt=a">${{ a }}</button>
              <button class="damount damount--custom" :class="{'damount--on':selectedAmt==='other'}"
                @click="selectedAmt='other'">{{ lbl('donateOther') }}</button>
            </div>
            <div class="donate-ctas">
              <button class="btn-donate-primary" @click="go('/donate')">
                <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                {{ lbl('donateNow') }}
              </button>
              <button class="btn-donate-ghost" @click="go('/about')">{{ lbl('donateLearn') }}</button>
            </div>
            <p class="donate-trust">🔒 {{ lbl('donateTrust') }}</p>
          </div>
          <div class="donate-side">
            <div class="impact-grid">
              <div class="impact-card impact-card--a"><span class="impact-card__ico">🎵</span><span class="impact-card__num">{{ sounds.length||'—' }}</span><span class="impact-card__lbl">{{ lbl('sound') }}</span></div>
              <div class="impact-card impact-card--b"><span class="impact-card__ico">📚</span><span class="impact-card__num">{{ writings.length||'—' }}</span><span class="impact-card__lbl">{{ lbl('writings') }}</span></div>
              <div class="impact-card impact-card--c"><span class="impact-card__ico">🖼️</span><span class="impact-card__num">{{ imageCollections.length||'—' }}</span><span class="impact-card__lbl">{{ lbl('images') }}</span></div>
              <div class="impact-card impact-card--d"><span class="impact-card__ico">💫</span><span class="impact-card__num">{{ allMemories.length||'—' }}</span><span class="impact-card__lbl">{{ lbl('memBadge') }}</span></div>
            </div>
            <blockquote class="donate-quote">
              <div class="donate-quote__mark">"</div>
              <p>{{ lbl('donateQuote') }}</p>
            </blockquote>
          </div>
        </div>
      </div>
    </section>

    <!-- FAB -->
    <button class="donate-fab" @click="go('/donate')" aria-label="Donate">
      <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
      <span class="donate-fab__pulse"/>
      <span class="donate-fab__lbl">{{ lbl('donate') }}</span>
    </button>

    <!-- NEWS MODAL -->
    <Teleport to="body">
      <Transition name="modal-fade">
        <div v-if="activeNews" class="modal-bg" @click.self="closeModal">
          <div class="modal" role="dialog" aria-modal="true">
            <button class="modal__close" @click="closeModal"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
            <div class="modal__hero">
              <img :src="safeImg(activeNews.coverUrl)||fallback" :alt="nTitle(activeNews)" @error="onImgErr"/>
              <div class="modal__hero-grad"/>
              <div class="modal__hero-info">
                <div class="modal__badges"><span class="nbadge">{{ nCat(activeNews) }}</span><span v-if="nSubCat(activeNews)" class="nbadge nbadge--sub">{{ nSubCat(activeNews) }}</span></div>
                <h2 class="modal__title">{{ nTitle(activeNews) }}</h2>
                <time class="modal__date">📅 {{ formatDate(activeNews.datePublished) }}</time>
              </div>
            </div>
            <div class="modal__body">
              <p class="modal__desc">{{ nDesc(activeNews) }}</p>
              <div class="modal__chips" v-if="nTags(activeNews).length"><h4 class="modal__chips-lbl">{{ lbl('tags') }}</h4><div class="chips-row"><span v-for="t in nTags(activeNews)" :key="t" class="chip chip--tag">#{{ t }}</span></div></div>
              <div class="modal__chips" v-if="nKeywords(activeNews).length"><h4 class="modal__chips-lbl">{{ lbl('keywords') }}</h4><div class="chips-row"><span v-for="k in nKeywords(activeNews)" :key="k" class="chip chip--kw">{{ k }}</span></div></div>
              <div v-if="activeNews.media?.length" class="modal__media">
                <h4 class="modal__chips-lbl">{{ lbl('media') }} ({{ activeNews.media.length }})</h4>
                <div class="modal__media-grid">
                  <div v-for="(m,mi) in activeNews.media" :key="mi" class="mm-item">
                    <div v-if="m.type==='IMAGE'" class="mm-img" @click="lightboxUrl=m.url||m.externalUrl"><img :src="m.url||m.externalUrl||fallback" @error="onImgErr"/></div>
                    <div v-else-if="m.type==='VIDEO'" class="mm-video"><iframe v-if="m.embedUrl" :src="m.embedUrl" allowfullscreen/><video v-else-if="m.url" controls><source :src="m.url" type="video/mp4"/></video><a v-else-if="m.externalUrl" :href="m.externalUrl" target="_blank" class="mm-ext">🎬 {{ lbl('openVideo') }}</a></div>
                    <div v-else-if="m.type==='AUDIO'" class="mm-audio"><span>🎵</span><audio v-if="m.url" controls><source :src="m.url" type="audio/mpeg"/></audio><a v-else-if="m.externalUrl" :href="m.externalUrl" target="_blank" class="mm-ext">🎵 {{ lbl('openAudio') }}</a></div>
                    <a v-else :href="m.url||m.externalUrl" target="_blank" class="mm-doc"><span>📄</span>{{ lbl('document') }} {{ mi+1 }}</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>

    <!-- LIGHTBOX -->
    <Teleport to="body">
      <Transition name="lb-fade">
        <div v-if="lightboxUrl" class="lightbox" @click="lightboxUrl=null">
          <button class="lightbox__x" @click="lightboxUrl=null"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
          <div class="lightbox__frame" @click.stop><img :src="lightboxUrl" @error="onImgErr"/></div>
        </div>
      </Transition>
    </Teleport>

  </main>
</template>
<script setup>
import { ref, computed, onMounted, onUnmounted, nextTick, watch } from 'vue'
import axios from 'axios'
import { useRouter } from 'vue-router'
import { API_BASE_URL } from '../consts.js'
import { useLanguageStore } from '@/stores/useLanguageStore'

const router = useRouter()
const lang = useLanguageStore()

const fallback = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='300' viewBox='0 0 400 300'%3E%3Crect width='400' height='300' fill='%231c1917'/%3E%3Crect x='160' y='95' width='80' height='65' rx='8' fill='%2344403c'/%3E%3Ccircle cx='185' cy='118' r='10' fill='%2357534e'/%3E%3Cpolygon points='160,160 200,125 230,148 260,125 280,160' fill='%2357534e'/%3E%3C/svg%3E"
const BAD_HOSTS = new Set(['example.com','placeholder.com','via.placeholder.com','dummyimage.com'])
function safeImg(url) {
  if (!url||typeof url!=='string'||!url.startsWith('http')) return null
  try { if (BAD_HOSTS.has(new URL(url).hostname)) return null } catch { return null }
  return url
}
const api = axios.create({ baseURL: API_BASE_URL, timeout: 15000, headers: {'Content-Type':'application/json', Accept:'application/json'} })

const i18n = {
  CKB: {
    heroKicker:'ناوەندی کەلەپووری کوردی', heroMain:'پاراستن و پەرەپێدانی کەلەپووری کوردی',
    heroDesc:'لە ڕێگەی دیجیتاڵکردن، توێژینەوە، و بڵاوکردنەوەی زانست و هونەر — بۆ نەوەکانی داهاتوو.',
    exploreNews:'دۆزینەوە', albumMemories:'یادگاریەکان', publications:'بڵاوکراوەکان', scrollDown:'خوارەوە',
    totalNews:'هەواڵ', totalPubs:'بڵاوکراوە', totalProj:'پڕۆژە', totalMem:'یادگاری',
    aboutBadge:'دەربارە', aboutTitle:'دەربارەی ناوەندی کەلەپووری کوردی',
    aboutLead:'ناوەندی کەلەپووری کوردی لە ساڵی ١٩٩٢ دامەزرا بۆ پاراستن و پەرەپێدانی میراسی کوردی.',
    aboutText:'ئێمە کار دەکەین لە بواری کۆکردنەوە، دیژیتاڵکردن، توێژینەوە، و بڵاوکردنەوەی کەلەپووری کوردی. گنجینەیەکی بەهایمانە لە دەنگ، وێنە، نووسین، و ڤیدیۆ بۆ داهاتووەکان دەپارێزین.',
    learnMore:'زیاتر بزانە', contactUs:'پەیوەندیمان پێوە بکە',
    pillarSound:'دەنگ و مۆسیقا', pillarSoundSub:'تۆمارکردن و پاراستنی دەنگ',
    pillarImage:'وێنەی مێژوویی', pillarImageSub:'ئەرشیڤکردنی وێنەی کوردی',
    pillarVideo:'ڤیدیۆ و فیلم', pillarVideoSub:'بەڵگەفیلم و فیلمی مێژوویی',
    pillarWriting:'نووسین و ئەدەبیات', pillarWritingSub:'کتێب، دەستنووس، و گۆڤار',
    newsBadge:'هەواڵ', newsTitle:'لە ناوەندی ڕووناکی', newsDesc:'دوا هەواڵ و دیاریترین بابەتەکان',
    readMore:'زیاتر بخوێنەوە', allNews:'هەموو هەواڵەکان',
    pubBadge:'بڵاوکراوەکان', pubTitle:'گنجینەی کەلەپووری', pubDesc:'دەنگ، ڤیدیۆ، نووسین و وێنە لەیەکدا',
    allPubs:'هەموو بڵاوکراوەکان',
    sound:'دەنگ', video:'ڤیدیۆ', writings:'نووسین', images:'وێنە',
    soundDesc:'تۆمارەکانی دەنگی کوردی — گۆرانی و مۆسیقا',
    videoDesc:'فیلم و بەڵگەفیلمی کوردی',
    writingDesc:'کتێب، دەستنووس و گۆڤارەکان',
    imageDesc:'گالەری وێنەی مێژوویی کوردی',
    singleTracks:'گۆرانی تاکەکان', soundGalleries:'ئەلبووم دەنگەکان',
    viewAll:'هەمووی ببینە', tracks:'گۆرانی', pages:'لاپەڕە', clips:'کلیپ',
    listen:'گوێدان', watch:'تەماشاکردن', read:'خوێندنەوە', view:'بینین',
    projBadge:'پڕۆژەکان', projTitle:'پڕۆژەکانمان', projDesc:'پڕۆژەکانی ناوەند لە بواری دەنگ، نووسین، وێنە و ڤیدیۆ',
    allProjects:'هەموو پڕۆژەکان', viewProject:'پڕۆژە ببینە',
    completed:'تەواوکراو', ongoing:'بەردەوام', all:'هەموو', reset:'سیفرکردنەوە',
    memBadge:'یادگاریەکان', memTitle:'ئەلبووم یادگاریەکان', memDesc:'دەنگ و ڤیدیۆی نایاب کە چیرۆکی کۆمەڵگا دەگێڕنەوە',
    allMemories:'هەموو یادگاریەکان', memAll:'هەموو', memSound:'دەنگەکان', memVideo:'ڤیدیۆکان',
    donateBadge:'پشتیوانی بکە', donateTitle:'یارمەتیدەری پاراستنی میراسی کوردی بە',
    donateLead:'بەخشینەکەت مێژووی کوردی دەخاتەوە رووناکایەتی. هەر بەخشینێک رووناکایەتی دەبێتەوە بۆ کوردایەتی.',
    donateR1:'تۆمارکردن و دیجیتاڵکردنی دەنگی کوردی', donateR2:'بڵاوکردنەوەی کتێب و دەستنووسی کوردی', donateR3:'پاراستنی ئەرشیڤی کوردی بۆ داهاتوو',
    donateOther:'بڕی دیکە', donateNow:'ئێستا بەخشین', donateLearn:'زیاتر بزانە',
    donateTrust:'بەخشینەکانت پارێزراوە و دەچێتە کاری ناوەند بەڕاستەوخۆ',
    donateQuote:'کوردایەتی نەمردووە، ئەگەر کوردی مێژووی کوردی بزانێت.',
    donate:'بەخشین', noContent:'ناوەڕۆک بەردەست نییە',
    tags:'تاگەکان', keywords:'کلیلەوشەکان', media:'میدیا',
    openVideo:'کردنەوەی ڤیدیۆ', openAudio:'کردنەوەی دەنگ', document:'بەڵگەنامە',
  },
  KMR: {
    heroKicker:'Dezgeha Mîrasa Kurdî', heroMain:'Parastina û Mezinkirina Mîrasa Kurdî',
    heroDesc:'Bi rêya dîjîtalkirin, lêkolîn û belavkirina zanist û hunerê — ji bo nifşên pêşerojê.',
    exploreNews:'Bigere', albumMemories:'Bîranîn', publications:'Weşandin', scrollDown:'Xwarê',
    totalNews:'Nûçe', totalPubs:'Weşandin', totalProj:'Proje', totalMem:'Bîranîn',
    aboutBadge:'Derbarê', aboutTitle:'Derbarê Dezgeha Mîrasa Kurdî',
    aboutLead:'Dezgeha Mîrasa Kurdî di sala 1992an de hat damezrandin ji bo parastina mîrasa Kurdî.',
    aboutText:'Em di warê berhevkirin, dîjîtalkirin, lêkolîn û belavkirina mîrasa Kurdî de dixebitin.',
    learnMore:'Bêtir bizane', contactUs:'Pê re têkilî daynin',
    pillarSound:'Deng û Muzîk', pillarSoundSub:'Tomarkirin û parastina deng',
    pillarImage:'Wêneyên Dîrokî', pillarImageSub:'Arşîvkirina wêneyên Kurdî',
    pillarVideo:'Vîdyo û Fîlm', pillarVideoSub:'Belgefîlm û fîlmên dîrokî',
    pillarWriting:'Nivîs û Edebiyat', pillarWritingSub:'Pirtûk, destxet û kovar',
    newsBadge:'Nûçe', newsTitle:'Di Navenda Ronahiyê de', newsDesc:'Nûçeyên dawî û mijarên herî girîng',
    readMore:'Bêtir bixwîne', allNews:'Hemû Nûçe',
    pubBadge:'Weşandin', pubTitle:'Xezîneya Mîrasê', pubDesc:'Deng, vîdyo, nivîsar û wêne di cih de',
    allPubs:'Hemû Weşandin',
    sound:'Deng', video:'Vîdyo', writings:'Nivîsar', images:'Wêne',
    soundDesc:'Tomarên dengê Kurdî — stran û muzîk', videoDesc:'Fîlm û belgefîlmên Kurdî',
    writingDesc:'Pirtûk, destxet û kovar', imageDesc:'Galeriya wêneyên dîrokî yên Kurdî',
    singleTracks:'Stranên Yekane', soundGalleries:'Albûmên Dengî',
    viewAll:'Hemûyan bibîne', tracks:'Stran', pages:'Rûpel', clips:'Klîp',
    listen:'Guhdarî bike', watch:'Temaşe bike', read:'Bixwîne', view:'Bibîne',
    projBadge:'Proje', projTitle:'Projeyên Me', projDesc:'Projeyên dezgehê di warê deng, nivîsar, wêne û vîdyo de',
    allProjects:'Hemû Proje', viewProject:'Projeyê bibîne',
    completed:'Qediyayî', ongoing:'Berdewam', all:'Hemû', reset:'Sifirkirin',
    memBadge:'Bîranîn', memTitle:'Albûma Bîranînê', memDesc:'Deng û vîdyoyên kêm ên ku çîroka civakê vedibêjin',
    allMemories:'Hemû Bîranîn', memAll:'Hemû', memSound:'Deng', memVideo:'Vîdyo',
    donateBadge:'Piştgirî bike', donateTitle:'Di Parastina Mîrasa Kurdî de Alîkar Be',
    donateLead:'Bexşîna te dîroka Kurdî ronî dike. Her bexşînek ronahî dibe ji bo Kurdayetiyê.',
    donateR1:'Tomarkirin û dîjîtalkirina dengê Kurdî', donateR2:'Belavkirina pirtûk û destxetên Kurdî', donateR3:'Parastina arşîva Kurdî ji bo pêşerojê',
    donateOther:'Mîqdara din', donateNow:'Niha bexşîn', donateLearn:'Bêtir bizane',
    donateTrust:'Bexşînên te ewle ne û rasterast diçin xebata dezgehê',
    donateQuote:'Kurdî nemiriye, eger Kurd dîroka xwe zanibe.',
    donate:'Bexşîn', noContent:'Naveroka berdest tune',
    tags:'Etiket', keywords:'Peyvên Kilîtê', media:'Medya',
    openVideo:'Vîdyoyê veke', openAudio:'Dengê veke', document:'Belge',
  }
}
function lbl(k) { return i18n[lang?.activeLang||'CKB']?.[k] ?? i18n['CKB']?.[k] ?? k }

const newsList=ref([]), newsLoading=ref(false)
const sounds=ref([]), videos=ref([]), writings=ref([]), imageCollections=ref([]), pubLoading=ref(false)
const projects=ref([]), projLoading=ref(false), projFilter=ref('all')
const memFilter=ref('all'), statsLoading=ref(true)
const selectedAmt=ref(25)
const heroSlideIndex=ref(0), slideDuration=6000
let slideTimer=null
const heroBgRef=ref(null)

const heroSlides=computed(()=>{
  const imgs=[]
  newsList.value.forEach(n=>{ const u=safeImg(n.coverUrl); if(u) imgs.push({url:u}) })
  sounds.value.forEach(s=>{ const u=safeImg(s.ckbCoverUrl)||safeImg(s.kmrCoverUrl); if(u) imgs.push({url:u}) })
  videos.value.forEach(v=>{ const u=safeImg(v.ckbCoverUrl)||safeImg(v.kmrCoverUrl); if(u) imgs.push({url:u}) })
  writings.value.forEach(w=>{ const u=safeImg(w.ckbCoverUrl)||safeImg(w.kmrCoverUrl); if(u) imgs.push({url:u}) })
  imageCollections.value.forEach(i=>{ const u=safeImg(i.ckbCoverUrl)||safeImg(i.kmrCoverUrl); if(u) imgs.push({url:u}) })
  return imgs.slice(0,12)
})
function goToSlide(i){ heroSlideIndex.value=i; restartSlideshow() }
function restartSlideshow(){
  if(slideTimer) clearInterval(slideTimer)
  slideTimer=setInterval(()=>{ if(heroSlides.value.length>1) heroSlideIndex.value=(heroSlideIndex.value+1)%heroSlides.value.length }, slideDuration)
}
watch(heroSlides, imgs=>{ if(imgs.length>1) restartSlideshow(); else { clearInterval(slideTimer); slideTimer=null } })

const heroStats=computed(()=>[
  {value:newsList.value.length>0?newsList.value.length+'+':'—',label:lbl('totalNews')},
  {value:(sounds.value.length+videos.value.length+writings.value.length+imageCollections.value.length)>0?(sounds.value.length+videos.value.length+writings.value.length+imageCollections.value.length)+'+':'—',label:lbl('totalPubs')},
  {value:projects.value.length>0?projects.value.length+'+':'—',label:lbl('totalProj')},
  {value:allMemories.value.length>0?allMemories.value.length+'+':'—',label:lbl('totalMem')},
])
const aboutPillars=computed(()=>[
  {icon:'🎵',title:lbl('pillarSound'),sub:lbl('pillarSoundSub')},
  {icon:'🖼️',title:lbl('pillarImage'),sub:lbl('pillarImageSub')},
  {icon:'🎬',title:lbl('pillarVideo'),sub:lbl('pillarVideoSub')},
  {icon:'📚',title:lbl('pillarWriting'),sub:lbl('pillarWritingSub')},
])

async function fetchNews(){
  newsLoading.value=true
  try{ const {data}=await api.get('/news'); newsList.value=data?.data||data||[] }catch{}finally{ newsLoading.value=false }
}
const displayedNews=computed(()=>{
  const al=lang?.activeLang||'CKB'
  return newsList.value.filter(n=>{ const l=n.contentLanguages||[]; return l.length===0||l.includes(al) })
    .sort((a,b)=>(b.datePublished||'').localeCompare(a.datePublished||'')).slice(0,4)
})
function nTitle(n){ if(!n) return ''; const c=lang?.activeLang==='KMR'; return(c?n.kmrContent?.title||n.ckbContent?.title:n.ckbContent?.title||n.kmrContent?.title)||'' }
function nDesc(n){ if(!n) return ''; const c=lang?.activeLang==='KMR'; return(c?n.kmrContent?.description||n.ckbContent?.description:n.ckbContent?.description||n.kmrContent?.description)||'' }
function nCat(n){ if(!n?.category) return ''; const c=lang?.activeLang==='KMR'; return(c?n.category.kmrName||n.category.ckbName:n.category.ckbName||n.category.kmrName)||'' }
function nSubCat(n){ if(!n?.subCategory) return ''; const c=lang?.activeLang==='KMR'; return(c?n.subCategory.kmrName||n.subCategory.ckbName:n.subCategory.ckbName||n.subCategory.kmrName)||'' }
function nTags(n){ if(!n) return []; return[...(lang?.activeLang==='KMR'?(n.tags?.kmr||[]):(n.tags?.ckb||[]))] }
function nKeywords(n){ if(!n) return []; return[...(lang?.activeLang==='KMR'?(n.keywords?.kmr||[]):(n.keywords?.ckb||[]))] }

async function fetchPublications(){
  pubLoading.value=true
  try{
    const [s,v,w,i]=await Promise.allSettled([api.get('/soundtracks'),api.get('/videos',{params:{page:0,size:100}}),api.get('/writings',{params:{page:0,size:100}}),api.get('/image-collections')])
    if(s.status==='fulfilled'){ const d=s.value.data; sounds.value=Array.isArray(d)?d:d?.data||[] }
    if(v.status==='fulfilled'){ const d=v.value.data; videos.value=d?.content||d?.data?.content||[] }
    if(w.status==='fulfilled'){ const d=w.value.data; writings.value=d?.data?.content||d?.content||[] }
    if(i.status==='fulfilled'){ const d=i.value.data; imageCollections.value=d?.data||d||[] }
  }finally{ pubLoading.value=false; statsLoading.value=false }
}
const singleTracks=computed(()=>sounds.value.filter(s=>(s.files?.length||0)===1))
const soundGalleries=computed(()=>sounds.value.filter(s=>(s.files?.length||0)>1))
function pCover(item){ if(!item) return fallback; const al=lang?.activeLang; return safeImg(al==='KMR'?item.kmrCoverUrl:item.ckbCoverUrl)||safeImg(item.ckbCoverUrl)||safeImg(item.kmrCoverUrl)||safeImg(item.hoverCoverUrl)||fallback }
function pTitle(item){ if(!item) return ''; const c=lang?.activeLang==='KMR'; return(c?item.kmrContent?.title||item.ckbContent?.title:item.ckbContent?.title||item.kmrContent?.title)||'' }
function pDesc(item){ if(!item) return ''; const c=lang?.activeLang==='KMR'; return(c?item.kmrContent?.description||item.ckbContent?.description:item.ckbContent?.description||item.kmrContent?.description)||'' }
function pWriter(item){ if(!item) return ''; const c=lang?.activeLang==='KMR'; return(c?item.kmrContent?.writer||item.ckbContent?.writer:item.ckbContent?.writer||item.kmrContent?.writer)||'' }

const projFilterDefs=computed(()=>[{val:'all',label:lbl('all')},{val:'ONGOING',label:lbl('ongoing')},{val:'COMPLETED',label:lbl('completed')}])
const filteredProjects=computed(()=>{
  const al=lang?.activeLang||'CKB'
  let list=projects.value.filter(p=>{ const l=p.contentLanguages||[]; return l.length===0||l.includes(al) })
  if(projFilter.value!=='all') list=list.filter(p=>p.status===projFilter.value)
  return list
})
function projTitle(p){ if(!p) return ''; const c=lang?.activeLang==='KMR'; return(c?p.kmrContent?.title||p.ckbContent?.title:p.ckbContent?.title||p.kmrContent?.title)||'' }
function projDesc(p){ if(!p) return ''; const c=lang?.activeLang==='KMR'; return(c?p.kmrContent?.description||p.ckbContent?.description:p.ckbContent?.description||p.kmrContent?.description)||'' }
function projTags(p){ if(!p) return []; return[...(lang?.activeLang==='KMR'?(p.tagsKmr||[]):(p.tagsCkb||[]))] }
async function fetchProjects(){
  projLoading.value=true
  try{ const {data}=await api.get('/projects/getAll',{params:{page:0,size:50}}); projects.value=data?.data?.content||data?.content||[] }catch{}finally{ projLoading.value=false }
}

const memFilterDefs=computed(()=>[{val:'all',icon:'💫',label:lbl('memAll')},{val:'sound',icon:'🎵',label:lbl('memSound')},{val:'video',icon:'🎬',label:lbl('memVideo')}])
const allMemories=computed(()=>[...sounds.value.filter(x=>x.albumOfMemories).map(x=>({...x,_mtype:'sound'})),...videos.value.filter(x=>x.albumOfMemories).map(x=>({...x,_mtype:'video'}))])
const filteredMemories=computed(()=>memFilter.value==='all'?allMemories.value:allMemories.value.filter(m=>m._mtype===memFilter.value))
function memCover(m){ return pCover(m) }
function memTitle(m){ return pTitle(m) }
function memDesc(m){ return pDesc(m) }

const lightboxUrl=ref(null)
function openImageLightbox(item){ const first=item.imageAlbum?.[0]; const url=first?.imageUrl||first?.externalUrl||pCover(item); if(url) lightboxUrl.value=url; else go('/publishments') }
const activeNews=ref(null)
function openNewsModal(item){ if(!item) return; activeNews.value=item; document.body.style.overflow='hidden' }
function closeModal(){ activeNews.value=null; document.body.style.overflow='' }

function go(path){ router.push(path) }
function scrollTo(sel){ document.querySelector(sel)?.scrollIntoView({behavior:'smooth',block:'start'}) }
function truncate(t,max){ if(!t) return ''; return t.length>max?t.slice(0,max)+'…':t }
function formatDate(v){ if(!v) return ''; try{ const d=new Date(v); if(isNaN(d)) return String(v); return d.toLocaleDateString(lang?.activeLang==='KMR'?'ku':'ckb',{year:'numeric',month:'long',day:'numeric'}) }catch{ return String(v) } }
function formatTime(s){ if(!s||isNaN(s)) return '0:00'; const m=Math.floor(s/60); const sec=Math.floor(s%60).toString().padStart(2,'0'); return m>=60?`${Math.floor(m/60)}:${String(m%60).padStart(2,'0')}:${sec}`:`${m}:${sec}` }
function onImgErr(e){ e.target.src=fallback }
function particleStyle(i){ const s=i*137.508; return {'--x':`${s%100}%`,'--y':`${(s*1.618)%100}%`,'--dur':`${14+(i*3.7)%20}s`,'--del':`${(i*1.2)%6}s`,'--sz':`${2+(i%4)}px`} }

let parallaxRaf=false
function handleParallax(){ if(!parallaxRaf){ requestAnimationFrame(()=>{ if(heroBgRef.value) heroBgRef.value.style.transform=`translateY(${window.scrollY*.3}px) scale(1.08)`; parallaxRaf=false }); parallaxRaf=true } }
let observer=null
function initAnimations(){
  const els=document.querySelectorAll('[data-animate]')
  observer=new IntersectionObserver(entries=>{ entries.forEach(e=>{ if(e.isIntersecting){ const d=parseInt(e.target.dataset.delay)||0; setTimeout(()=>e.target.classList.add('animated'),d); observer.unobserve(e.target) } }) },{threshold:.08,rootMargin:'0px 0px -40px 0px'})
  els.forEach(el=>observer.observe(el))
}
function handleKey(e){ if(e.key==='Escape'){ if(lightboxUrl.value){lightboxUrl.value=null;return}; if(activeNews.value) closeModal() } }
onMounted(async()=>{
  initAnimations(); window.addEventListener('scroll',handleParallax,{passive:true}); document.addEventListener('keydown',handleKey)
  await Promise.allSettled([fetchNews(),fetchPublications(),fetchProjects()])
  restartSlideshow(); nextTick(initAnimations)
})
onUnmounted(()=>{
  if(observer) observer.disconnect(); if(slideTimer) clearInterval(slideTimer)
  window.removeEventListener('scroll',handleParallax); document.removeEventListener('keydown',handleKey)
  document.body.style.overflow=''
})
</script>

<style scoped>
/* CSS Variables */
</style>