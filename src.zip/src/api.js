import axios from 'axios'
import { getCached, setCache, invalidateCache } from '@/utils/apiCache'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8080',
  withCredentials: false,
})

// ── Request interceptor: attach JWT + cache headers ──────────
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('khi_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }

  // Check in-memory/localStorage cache for GET requests
  if (config.method === 'get' && !config._skipCache) {
    const cached = getCached(config.baseURL + config.url + (config.params ? '?' + new URLSearchParams(config.params).toString() : ''))
    if (cached) {
      // Return cached data by setting up an adapter override
      config.adapter = () => Promise.resolve({
        data: cached,
        status: 200,
        statusText: 'OK (cached)',
        headers: {},
        config,
      })
    }
  }

  return config
})

// ── Response interceptor: cache GETs, invalidate on mutations ──
api.interceptors.response.use(
  (response) => {
    const { config } = response

    // Cache successful GET responses
    if (config.method === 'get' && response.status === 200 && !config._skipCache) {
      const fullUrl = config.baseURL + config.url + (config.params ? '?' + new URLSearchParams(config.params).toString() : '')

      // Determine TTL based on resource type
      const ttl = getCacheTTL(config.url)
      setCache(fullUrl, response.data, ttl)
    }

    // Invalidate relevant caches on mutations
    if (['post', 'put', 'patch', 'delete'].includes(config.method)) {
      // Extract the resource base path: /api/projects/123 → /api/projects
      const basePath = extractBasePath(config.url)
      if (basePath) {
        invalidateCache(config.baseURL + basePath)
      }
    }

    return response
  },
  (error) => {
    const status = error?.response?.status
    if (status === 401 || status === 403) {
      localStorage.removeItem('khi_token')
      localStorage.removeItem('khi_user')
      sessionStorage.clear()
      if (!window.location.pathname.startsWith('/login')) {
        window.location.href = '/login?expired=1'
      }
    }
    return Promise.reject(error)
  }
)

// ── Cache TTL configuration ─────────────────────────────────
function getCacheTTL(url) {
  // Static-ish resources: cache longer
  if (url.includes('/api/about'))    return 10 * 60 * 1000  // 10 min
  if (url.includes('/api/projects')) return 5 * 60 * 1000   // 5 min
  if (url.includes('/api/news'))     return 3 * 60 * 1000   // 3 min
  // Dynamic resources: shorter cache
  if (url.includes('/api/user'))     return 60 * 1000        // 1 min
  return 5 * 60 * 1000  // Default 5 min
}

// ── Helper: extract resource base path ──────────────────────
function extractBasePath(url) {
  // /api/projects/123/edit → /api/projects
  const match = url.match(/^(\/api\/[^/?]+)/)
  return match ? match[1] : null
}

/**
 * Convenience: fetch without cache (e.g., for /api/user/me).
 * Usage: api.get('/api/user/me', { _skipCache: true })
 */

export default api
